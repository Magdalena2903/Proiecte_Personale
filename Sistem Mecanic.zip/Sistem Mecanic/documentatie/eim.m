%   1)numarul de dinti
z1=12
z2=34
%   2)coeficientii de deplasare a profilurilor
x1=0.60
x2=0.53
%   3)modulul
m=2
%   4)unghiul de angrenare
alfa0 = 20*pi/180 % 20 de grade in radiani
inva0 = 0.01490
invalfa = inva0+(2*(x1+x2)*tan(alfa0))/(z1+z2)
%   5)coeficientul de modificare a distantei dintre axe
alfa = 25.6833*pi/180
y = ((z1+z2)/2)*((cos(alfa0)/cos(alfa))-1)
%   6)distanta axiala
a = m*(z1+z2)*cos(alfa0)/(2*cos(alfa))
%   7)coeficientul de scurtare a inaltimii dintilor
psi = x1+x2-y
%   8)inaltimea dintilor
h = m*(2.25-psi)
%   9)diametrul cercurilor de divizare
d1 = m*z1
r1 = d1/2
d2 = m*z2
r2 = d2/2
%   10)diametrul cercurilor de baza
db1 = m*z1*cos(alfa0)
rb1 = db1/2
db2 = m*z2*cos(alfa0)
rb2 = db2/2
%   11)diametrul cercurilor de rostogolire
dw1 = m*z1*cos(alfa0)/cos(alfa)
rw1 = dw1/2
dw2 = m*z2*cos(alfa0)/cos(alfa)
rw2 = dw2/2
%   12)diametrul cercurilor de cap
da1 = m*(z1+2+2*x1-2*psi)
ra1 = da1/2
da2 = m*(z2+2+2*x2-2*psi)
ra2 = da2/2
%   13)diametrul cercurilor de picior
df1 = m*(z1-2+2*x1-0.5)
rf1 = df1/2
df2 = m*(z2-2+2*x2-0.5)
rf2 = df2/2
%   14)arcele dintilor pe cercurile de divizare
s1 = pi*m/2 + 2*m*x1*tan(alfa0)
s2 = pi*m/2 + 2*m*x2*tan(alfa0)
%   15)gradul de acoperire
E = (sqrt(ra2^2 - rb2^2) + sqrt(ra1^2-rb1^2) -a*sin(alfa))/(pi*m*cos(alfa0))