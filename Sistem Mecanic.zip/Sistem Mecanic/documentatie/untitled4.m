i=18; h=7+0.5i
phi_u=66+i; phi_r=80;
phi_R=60; phi_c=360-phi_R-phi_r-phi_u
alfa=45;
%pozitia
phi=0:phi_u; %intervalul de urcare
s=h*(phi/phi_u-1/(2*pi)*sin(2*pi/phi_u*phi));
subplot(311), plot(phi,s), grid;
title('Variatia cursei tachetului'); hold on;
phi=phi_u:phi_c; %intervalul de repaus
s=ones(size(phi))*h;
plot(phi,s); hold on
phi=phi_c:-1:0; %interval coborare
s=h/2*(1-cos(pi/phi_c*phi));
plot(2*phi_c-phi,s);
x = [253, 360]; y = [0, 0];plot(x, y)
%viteza
phi=0:phi_u; %intervalul de urcare
vr=h/phi_u*(1-cos(2*pi/phi_u*phi));
subplot(312), plot(phi,vr), grid;
title('Variatia vitezei'); hold on;
phi=phi_u:phi_c; %intervalul de repaus
s=ones(size(phi))*0;
plot(phi,s); hold on
phi=phi_c:-1:0; %interval coborare
vr=pi*h/(2*phi_c)*sin(pi/phi_c*phi);
plot(2*phi_c-phi,-vr);
x = [274, 360];y = [0, 0];plot(x, y)
%acceleratia
phi=0:phi_u; %intervalul de urcare
ar=2*h*pi/((phi_u)^2)*sin(2*pi/phi_u*phi);
subplot(313), plot(phi,ar), grid;
title('Variatia acceleratiei'); hold on;
phi=phi_u:phi_c; %intervalul de repaus
s=ones(size(phi))*0;
plot(phi,s); hold on
phi=phi_c:-1:0; %interval coborare
ar=(pi^2*h)/(2*(phi_c^2))*cos(pi/phi_c*phi);
plot(2*phi_c-phi,ar); hold on
x = [136.9, 137]; y = [0, -0.00184046];plot(x, y)
x = [272.9, 273];y = [0.00183998, 0];plot(x, y)
x = [273, 360];y = [0, 0];plot(x, y)

