t = Olariu(:,1);
u = Olariu(:,2);
y2 = Olariu(:,4);
figure; plot(t,u,t,y2)
%% rezonanta
i1=398;
i2=420;
i3=393;
i4=414; 

k=mean(y2)/mean(u)%factorul de proportionalitate
Mr=((y2(i1)-y2(i2))/(u(i3)-u(i4)))/k %amplificarea la rezonanta
z=sqrt((Mr-sqrt(Mr^2-1)))/(2/Mr)%factorul de amortizare
Tr=2*(t(i4)-t(i3))%perioada la rezonanta
wr=2*pi/Tr%pulsatia la rezonanta
wn=wr/sqrt(1-2*z^2)%pulsatia naturala de oscilatie
dt=t(i1)-t(i3)%timpul dintre maximul intrarii si maximul iesirii
phr=(t(i3)-t(i1))*wr%defazajul

Tz=tan(phr+atan(sqrt(1-2*z^2)/z))/wr%constanta de timp a zeroului

num=k*wn^2*[Tz 1]
den=[1 2*z*wn wn^2]
 
 Hc=tf(num, den)
% a=y(i1)-Tz*(y(i1)-y(i1-1))/dt
% b=y(i2)-Tz*(y(i2)-y(i2-1))/dt
% c=u(i3)-u(i4)
% %Mrc=(a-b)/c/k %1.42

Mrc=((y2(i1)-y2(i2))/(u(i3)-u(i4))-Tz*(y2(2)-y2(1))/dt)/k%1.4670
zc=sqrt(Mrc-sqrt(Mrc^2-1))/(2/Mrc)
wnc=wr/sqrt(1-2*zc^2)
Tzc=tan(phr+atan(sqrt(1-2*zc^2)/zc))/wr
numc=[k*wnc^2*Tzc k*wnc^2]
denc=[1 2*zc*wnc wnc^2]
[Ac, Bc, Cc, D]=tf2ss(numc, denc)
A_FCOc=[-2*zc*wnc 1; -wnc^2 0];
B_FCOc=[Tzc*k*wnc^2; k*wnc^2];
C_FCOc=[1 0];

y2cc=lsim(A_FCOc,B_FCOc,C_FCOc,D,u,t,[y2(1), (y2(2)-y2(1))/dt+2*zc*wnc*y2(1)+Tzc*wnc^2*k*u(1)])
plot(t, [y2 y2cc])

J=norm(y2-y2cc)/sqrt(length(y2)) 
empn=norm(y2-y2cc)/norm(y2-mean(y2))*100
%% datele identificate
Te=t(2)-t(1)
data_id=iddata(y2, u,Te)
data_vd=iddata(y2, u,Te)
%% identificarea cu ARX
m_arx = arx(data_id,[2,2,1]) %identific polul pt partea mecanica, nu am zerouri +tact intarziere 

%validarea statistica
figure ; resid(m_arx,data_vd)
%ne intereseaza primele 2 esantioane 
%gradul de suprapunere
figure; compare(m_arx,data_vd)
%eroarea de predictie 100 - ce da matlab

%functia de transfer
H1=tf(m_arx.B,m_arx.A,Te,'variable','z^-1')
%% identificarea cu ARMAX
m_armax = armax(data_id,[2,2,2,1]) %identific polul pt partea mecanica, nu am zerouri +tact intarziere 

%validarea statistica nivel de incredere mai bun 
figure ; resid(m_armax,data_vd)
%ne intereseaza primele 2 esantioane 
%gradul de suprapunere
figure; compare(m_armax,data_vd)

%functia de transfer
H2=tf(m_armax.B,m_armax.A,Te,'variable','z^-1')

%valoarea lui k se identifica in regim stationar (aici nu avem stationar)
%% metoda IV
nA=2;
nB=2 %zerouri nu avem
nd=1; %interfata A/D
m_iv=iv4(data_id,[nA,nB,nd])
%validare statistica nA+nB+nF
figure; resid(m_iv,data_vd);
%gradul de suprapunere 
figure; compare(m_iv,data_vd)

Hd_iv=tf(m_iv.B,m_iv.A,Te,'variable','z^-1')
Hc_iv=d2c(Hd_iv)
%% metoda OE
nF=2;%un pol
nB=2;%nu zero
nd=1;%interfatare
m_oe=oe(data_id,[nB,nF,nd])
%validare statistica nA+nB+nF
figure; resid(m_oe,data_vd);
%gradul de suprapunere 
figure; compare(m_oe,data_vd)

Hd_oe=tf(m_oe.B,m_oe.F,Te,'variable','z^-1')
Hc_oe=d2c(Hd_oe)

%% reprezentarea tuturor rezultatelor
compare(m_arx,m_iv,m_armax,m_oe,data_vd)