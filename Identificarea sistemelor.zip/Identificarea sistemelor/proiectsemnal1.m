t = Olariu(:,1); % timpul
u = Olariu(:,2); % intrarea
y1 = Olariu(:,3); % primul semnal de iesire
%y2 = Olariu(:,4); % al doilea semnal de iesire
% subplot(211); plot(t,u,'r') %semnal intrare
% subplot(212); plot(t,y1) %semnal 1 iesire
%subplot(212); plot(t,y2,'g') %semnal 2 iesire
figure; plot(t,u,t,y1) %semnalele impreuna
%model (intrare-iesire) 
%% rezonanta
i1 = 353 % ymax
i2 = 377 % ymin
i3 = 346 % umax
i4 = 369 % umin
%semnal in conditii initiale nenule
k=mean(y1)/mean(u)
Mr=((y1(i1)-y1(i2))/(u(i3)-u(i4)))/k %amplificarea de rezonanta(maxima)modulul functiei de tranfer 
%zetta=sqrt((Mr-sqrt(Mr^2-1)))/(2/Mr) 
z = 0.35
Tr=2*(t(i4)-t(i3)) %perioada de rezonanta    ; perioada de 2 ori intre 2 maxime
wr=2*pi/Tr %pulsatia de rezonanta 
wn=wr/sqrt(1-2*z^2) % pulsatia naturala

%folosim model spatiul starilor
A=[0 1; -wn^2 -2*z*wn]
B=[0; k*wn^2]
C=[1 0]
D=0
y1c=lsim(A,B,C,D,u,t,[y1(1), (y1(2)-y1(1))/(t(2)-t(1))]); %aici fac conditiile initiale nule
plot(t, [y1, y1c])
dt=t(2)-t(1) %perioada de achizitie; intarzierea semnalului de iesire
 %diferenta dintre 2 timpi consecutivi

 %% validarea
J=norm(y1-y1c)/sqrt(length(y1)) % eroare medie patratica
empn=norm(y1-y1c)/norm(y1-mean(y1))*100 % eroare medie patratica normalizata
%% datele identificate
Te=t(2)-t(1) % timp de achiziţie 
data_id=iddata(y1, u,Te)
data_vd=iddata(y1, u,Te)
%% identificarea cu ARX
m_arx = arx(data_id,[2,1,1]) %identific polul pt partea mecanica, nu am zerouri +tact intarziere 

%validarea statistica
figure ; resid(m_arx,data_vd)
%ne intereseaza primele 2 esantioane 
%gradul de suprapunere
figure; compare(m_arx,data_vd) %gradul de suprapunere
                                                                   %eroarea de predictie 100 - ce da matlab
%functia de transfer
H1=tf(m_arx.B,m_arx.A,Te,'variable','z^-1')
%% identificarea cu ARMAX
m_armax = armax(data_id,[2,1,2,1]) %identific polul pt partea mecanica, nu am zerouri +tact intarziere 

%validarea statistica nivel de incredere mai bun 
figure ; resid(m_armax,data_vd)
%ne intereseaza primele 2 esantioane 
figure; compare(m_armax,data_vd)%gradul de suprapunere

%functia de transfer
H2=tf(m_armax.B,m_armax.A,Te,'variable','z^-1')

%valoarea lui k se identifica in regim stationar (aici nu avem stationar)
%% metoda IV
nA=2;
nB=1 %zerouri nu avem
nd=1; %interfata A/D
m_iv=iv4(data_id,[nA,nB,nd])
%validare statistica nA+nB+nF
figure; resid(m_iv,data_vd);
%gradul de suprapunere 
figure; compare(m_iv,data_vd)

%functiile de transfer
Hd_iv=tf(m_iv.B,m_iv.A,Te,'variable','z^-1')
Hc_iv=d2c(Hd_iv)
%% metoda OE
nF=2;%un pol
nB=1;%nu zero
nd=1;%interfatare
m_oe=oe(data_id,[nB,nF,nd])
%validare statistica nA+nB+nF
figure; resid(m_oe,data_vd);
%gradul de suprapunere 
figure; compare(m_oe,data_vd)

% functiile de transfer
Hd_oe=tf(m_oe.B,m_oe.F,Te,'variable','z^-1')
Hc_oe=d2c(Hd_oe)
%% reprezentarea tuturor rezultatelor
compare(m_arx,m_iv,m_armax,m_oe,data_vd)
